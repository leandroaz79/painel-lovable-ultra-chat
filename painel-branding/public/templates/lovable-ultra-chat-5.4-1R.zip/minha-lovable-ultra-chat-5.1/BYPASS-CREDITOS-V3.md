# Bypass de Créditos Lovable — v3 (Server-Side Proxy)

## Status: ✓ Funcional (21/06/2026)

## Arquitetura

### Problema Original

O backend do Lovable parou de honrar `intent: fix_error` em requisições feitas diretamente do navegador (client-side). Mesmo com o payload idêntico, os créditos da conta Lovable são consumidos.

### Solução: Server-Side Proxy

Ao invés de enviar o `fix_error` diretamente do navegador, a requisição é roteada através de uma **edge function Supabase** (`send-lovable-message`) que faz o wrapping `fix_error` server-side. O Lovable vê a requisição vindo do servidor Supabase, não do navegador do usuário, resultando em **0 créditos consumidos**.

```
Usuário → Extensão → Proxy Supabase (server-side) → API Lovable → 0 créditos
```

### Fluxo Detalhado

```
1. Usuário ativa licença
   → validate-license (POST)
   ← { valid: true, session_id, ts_session_token, ... }
   → Salva ts_session_token no chrome.storage.local

2. Heartbeat (60s)
   → validate-license (POST, heartbeat: true)
   ← { valid: true, ts_session_token, ... }
   → Atualiza ts_session_token no storage

3. Usuário envia prompt
   → sendPromptNativeViaBackground()
     ├─ Lê ts_session_token do storage
     ├─ Se token existe:
     │   → POST send-lovable-message
     │   │  Headers: X-TS-Session: <ts_session_token>
     │   │  Body: { projectId, lovableBearer, message, files, currentPage }
     │   │
     │   ├─ Se 200 OK → { success: true, method: 'proxy' }
     │   │               ✓ Créditos NÃO consumidos
     │   │
     │   └─ Se erro → Fallback via pageHook (consome créditos)
     │
     └─ Se token vazio: Fallback via pageHook (consome créditos)
```

## Componentes Modificados

### 1. `content.js` (popup flutuante)

| Local | O que faz |
|-------|-----------|
| Linha 12 | Constante `SEND_LOVABLE_URL` apontando para `send-lovable-message` |
| Linha 184 | `storage.get` inclui `'ts_session_token'` |
| Linhas 209–240 | Bloco proxy: tenta `send-lovable-message` primeiro |
| Linha 210 | Sessão token lida de `storage.ts_session_token` |
| Linha 221 | Suporte a `planMode` no proxy |
| Linha 727 | `validateLicense` salva `ts_session_token` + `ts_session_expires_at` |
| Linhas 1454–1457 | Heartbeat atualiza `ts_session_token` |

### 2. `sidepanel.js` (painel lateral)

| Local | O que faz |
|-------|-----------|
| Linha 16 | Constante `SEND_LOVABLE_URL` apontando para `send-lovable-message` |
| Linha 172 | `storage.get` inclui `"ts_session_token"` |
| Linhas 221–252 | Bloco proxy: tenta `send-lovable-message` primeiro |
| Linha 222 | Sessão token lida de `storage.ts_session_token` |
| Linha 233 | Suporte a `planMode` no proxy |
| Linha 908 | `validateLicense` salva `ts_session_token` + `ts_session_expires_at` |
| Linhas 2303–2304 | Heartbeat atualiza `ts_session_token` |

### 3. `manifest.json` (sem alterações necessárias)

O `host_permissions` já inclui `https://wogunbzijppmeuleitjq.supabase.co/*`.

## Tokens: `session_id` vs `ts_session_token`

O `validate-license` retorna **dois tokens diferentes**:

| Token | Storage Key | Uso |
|-------|-------------|-----|
| `session_id` | `ql_session_id` | Sessão geral da licença (heartbeat, validações) |
| `ts_session_token` | `ts_session_token` | Autorização para o proxy `send-lovable-message` |

**A confusão inicial:** o código tentava usar `ql_session_id` como `X-TS-Session`, mas o proxy rejeitava com 403 "Sessão TS inválida". O token correto é `ts_session_token`.

## Proxy: `send-lovable-message`

**Endpoint:** `POST https://wogunbzijppmeuleitjq.supabase.co/functions/v1/send-lovable-message`

**Headers:**
```
Content-Type: application/json
apikey: <SUPABASE_ANON_KEY>
Authorization: Bearer <SUPABASE_ANON_KEY>
X-TS-Session: <ts_session_token>
```

**Body:**
```json
{
  "projectId": "uuid-do-projeto",
  "lovableBearer": "token-do-lovable",
  "message": "prompt-do-usuario",
  "files": [],
  "currentPage": "https://lovable.dev/projects/...",
  "threadId": "main"
}
```

**Resposta (200 OK):**
```json
{
  "id": "...",
  "credits_used": 0,
  ...
}
```

## Fallback

Se o proxy falhar (token ausente, expirado, erro de rede), o sistema cai no caminho original:
- `content.js`: `lovableApiFetch` → `pageHook.js` → fetch original → API Lovable
- `sidepanel.js`: `lovableApiFetch` → background → content → pageHook → API Lovable

**O fallback CONSOOME créditos** e é intencionalmente mantido como contingência.

## Manutenção do Token

O `ts_session_token` é refrescado automaticamente a cada 60 segundos pelo heartbeat. Não requer ação do usuário após a ativação inicial da licença.

## Diagnóstico

Para verificar o estado atual:
```js
chrome.storage.local.get(['ts_session_token', 'ql_session_id', 'ql_license_valid'], console.log)
```

Para forçar recaptura do token, recarregue a página do Lovable ou reative a licença.
