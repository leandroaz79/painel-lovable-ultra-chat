(function () {

let capturedToken = null;
let capturedProjectId = null;
let capturedHeaders = {};
let originalFetch = null;

function getProjectFromPage(){
  try{
    const m = window.location.pathname.match(/projects\/([0-9a-fA-F-]{36})/i);
    return m ? m[1] : null;
  }catch{ return null; }
}

function extractProjectIdFromUrl(url){
  try{
    const m = String(url).match(/projects\/([0-9a-fA-F-]{36})/i);
    return m ? m[1] : null;
  }catch{ return null; }
}

function notifyFound(token, projectId, force = false){
  const newProject = projectId || getProjectFromPage();
  const normalizedToken = typeof token === "string" ? token.replace(/^Bearer\s+/i, "").trim() : null;
  let changed = false;
  if(normalizedToken && normalizedToken !== capturedToken){ capturedToken = normalizedToken; changed = true; }
  if(newProject && newProject !== capturedProjectId){ capturedProjectId = newProject; changed = true; }
  if(!changed && !force) return;
  window.postMessage({ type:"lovableTokenFound", token:capturedToken, projectId:capturedProjectId },"*");
}

window.addEventListener("message", (event)=>{
  if(event.source !== window) return;
  if(!event.data) return;
  if(event.data.type === "lovableRequestToken"){
    notifyFound(capturedToken, getProjectFromPage() || capturedProjectId, true);
  }
  if(event.data.type === "TS_PAGE_UPLOAD_TO_GCS"){
    const { requestId, uploadUrl, contentType, arrayBuffer } = event.data;
    (async () => {
      try {
        const blob = new Blob([arrayBuffer], { type: contentType });
        const res = await fetch(uploadUrl, {
          method: "PUT",
          headers: { "Content-Type": contentType },
          body: blob
        });
        window.postMessage({ type: "TS_PAGE_UPLOAD_TO_GCS_RESULT", requestId, success: res.ok, status: res.status }, "*");
      } catch (err) {
        window.postMessage({ type: "TS_PAGE_UPLOAD_TO_GCS_RESULT", requestId, success: false, status: 0, error: String(err && err.message || err) }, "*");
      }
    })();
  }

  // ===== BYPASS SEND HANDLER =====
  // Uses the ORIGINAL fetch captured at document_start, bypassing Lovable's wrappers
  if(event.data.type === "LOVABLE_ULTRA_BYPASS_SEND"){
    const { requestId, url, options } = event.data;
    (async () => {
      try {
        const fetchFn = originalFetch || window.fetch;
        const res = await fetchFn(url, {
          method: (options && options.method) || "POST",
          headers: (options && options.headers) || {},
          body: (options && options.body) || null,
          credentials: "include",
        });
        const text = await res.text();
        let data;
        try { data = JSON.parse(text); } catch(e) { data = { raw: text }; }
        window.postMessage({
          type: "LOVABLE_ULTRA_BYPASS_RESULT",
          requestId,
          ok: res.ok,
          status: res.status,
          data,
        }, "*");
      } catch (err) {
        window.postMessage({
          type: "LOVABLE_ULTRA_BYPASS_RESULT",
          requestId,
          ok: false,
          status: 0,
          data: { error: (err && err.message) || "fetch failed" },
        }, "*");
      }
    })();
  }
});

(function wrapFetch(){
  try{
    originalFetch = window.fetch;
    window.fetch = async function(...args){
      let reqUrl = "";
      try{
        reqUrl = typeof args[0] === "string" ? args[0] : ((args[0] && args[0].url) || "");
        let opts = args[1] || {};
        let auth = null;
        if(args[0] instanceof Request){
          reqUrl = args[0].url || reqUrl;
          auth = (args[0].headers && typeof args[0].headers.get === "function") ? (args[0].headers.get("Authorization") || args[0].headers.get("authorization")) : null;
        }
        if(opts.headers){
          if(opts.headers instanceof Headers) auth = opts.headers.get("Authorization");
          else if(typeof opts.headers === "object") auth = opts.headers.Authorization || opts.headers.authorization;
        }
        const pid = extractProjectIdFromUrl(reqUrl);
        if(auth && auth.startsWith("Bearer ")){
          const rawToken = auth.slice(7);
          notifyFound(rawToken, pid);
        }

        // Capture headers from native Lovable requests
        if(reqUrl && reqUrl.indexOf("api.lovable.dev") !== -1){
          try {
            let allHeaders = {};
            if(opts.headers){
              if(opts.headers instanceof Headers){
                opts.headers.forEach((v, k) => { allHeaders[k.toLowerCase()] = v; });
              } else if(typeof opts.headers === "object"){
                Object.keys(opts.headers).forEach(k => { allHeaders[k.toLowerCase()] = opts.headers[k]; });
              }
            }
            if(args[0] instanceof Request && args[0].headers && typeof args[0].headers.forEach === "function"){
              args[0].headers.forEach((v, k) => { allHeaders[k.toLowerCase()] = v; });
            }
            if(allHeaders["x-client-git-sha"]) capturedHeaders.gitSha = allHeaders["x-client-git-sha"];
            if(allHeaders["x-tenant-id"]) capturedHeaders.tenantId = allHeaders["x-tenant-id"];
            if(allHeaders["x-workspace-id"]) capturedHeaders.workspaceId = allHeaders["x-workspace-id"];
            if(allHeaders["x-browser-session-id"]) capturedHeaders.browserSessionId = allHeaders["x-browser-session-id"];
            if(allHeaders["accept-language"]) capturedHeaders.acceptLanguage = allHeaders["accept-language"];
          } catch(_){}
        }
      }catch(e){}
      return originalFetch.apply(this, args);
    };
  }catch(e){ console.warn("[QuantumHook] erro fetch",e); }
})();

(function wrapXHR(){
  try{
    const origOpen = XMLHttpRequest.prototype.open;
    const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.open = function(method,url){
      this._lovable_url = url;
      return origOpen.apply(this,arguments);
    };
    XMLHttpRequest.prototype.setRequestHeader = function(name,value){
      if(name && name.toLowerCase()==="authorization" && value && value.startsWith("Bearer ")){
        const rawToken = value.slice(7);
        notifyFound(rawToken, extractProjectIdFromUrl(this._lovable_url));
      }
      return origSetHeader.apply(this,arguments);
    };
  }catch(e){ console.warn("[QuantumHook] erro xhr",e); }
})();

setInterval(()=>{
  const p = getProjectFromPage();
  if(p && p !== capturedProjectId){
    capturedProjectId = p;
    window.postMessage({ type:"lovableTokenFound", token:capturedToken, projectId:p },"*");
  }
},1500);

})();
