// ============================================================
// TS Community - Central Branding Configuration
// ------------------------------------------------------------
// Gerado pelo painel de branding.
// ============================================================

(function () {
  if (window.__tsBrandingInstalled) return;
  window.__tsBrandingInstalled = true;

  var DEFAULTS = {
    extensionName: "Lovable Ultra Chat",
    brandName: "Lovable Ultra Chat",
    primaryColor: "#7C5AFF",
    secondaryColor: "#6DE8FF",
    whatsappLinks: {
      support: "https://wa.me/556781880921",
      sales: "https://wa.me/556781880921",
      community: "https://chat.whatsapp.com/JPmVOlIJ66YG2M9ug9HUjX"
    }
  };

  function isValidHexColor(c) {
    return typeof c === "string" && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(c.trim());
  }
  function normalizeHex(c) {
    c = c.trim();
    if (c.length === 4) { c = "#" + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]; }
    return c.toLowerCase();
  }
  function hexToRgb(hex) {
    hex = normalizeHex(hex);
    var n = parseInt(hex.slice(1), 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }
  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
  function adjustHexColor(hex, delta) {
    var rgb = hexToRgb(hex);
    var f = delta / 100;
    function adj(v) {
      if (f < 0) return Math.round(v * (1 + f));
      return Math.round(v + (255 - v) * f);
    }
    var r = clamp(adj(rgb.r), 0, 255).toString(16).padStart(2, "0");
    var g = clamp(adj(rgb.g), 0, 255).toString(16).padStart(2, "0");
    var b = clamp(adj(rgb.b), 0, 255).toString(16).padStart(2, "0");
    return "#" + r + g + b;
  }
  function isValidWaUrl(url) {
    if (typeof url !== "string") return false;
    return /^https:\/\/(wa\.me|chat\.whatsapp\.com)\//i.test(url.trim());
  }

  function applyBrandColor(primary, secondary) {
    var color = isValidHexColor(primary) ? normalizeHex(primary) : DEFAULTS.primaryColor;
    var color2 = isValidHexColor(secondary) ? normalizeHex(secondary) : DEFAULTS.secondaryColor;
    var rgb = hexToRgb(color);
    var hover = adjustHexColor(color, -12);
    var rgbStr = rgb.r + ", " + rgb.g + ", " + rgb.b;

    var root = document.documentElement;
    root.style.setProperty("--ts-brand-primary", color);
    root.style.setProperty("--ts-brand-primary-rgb", rgbStr);
    root.style.setProperty("--ts-brand-primary-hover", hover);
    root.style.setProperty("--ts-brand-primary-soft", "rgba(" + rgbStr + ", 0.12)");
    root.style.setProperty("--ts-brand-primary-border", "rgba(" + rgbStr + ", 0.35)");
    root.style.setProperty("--ts-brand-primary-glow", "rgba(" + rgbStr + ", 0.35)");
    root.style.setProperty("--ts-brand-secondary", color2);
    root.style.setProperty("--ts-brand-gradient", "linear-gradient(135deg, " + color + ", " + color2 + ")");
  }

  var BRAND_NAME_SELECTORS = [
    ".ql-title", ".ql-brand", ".sp-brand-text",
    "[data-ts-brand='name']", "[data-ts-brand-name]"
  ];
  var FOOTER_TEXT_SELECTORS = [".ql-badge-mz", ".sp-footer-badge", "[data-ts-brand='footer']"];
  var ORIGINAL_BRAND_REGEX = /(?:TS Community|Lovable Ultra Chat)/i;

  function applyBrandTexts(cfg) {
    try {
      if (document.title && ORIGINAL_BRAND_REGEX.test(document.title)) {
        document.title = document.title.replace(ORIGINAL_BRAND_REGEX, cfg.brandName);
      }
    } catch (_) {}
    function setText(el, value) {
      if (!el) return;
      var changed = false;
      el.childNodes.forEach(function (n) {
        if (n.nodeType === 3) {
          var t = n.nodeValue;
          if (ORIGINAL_BRAND_REGEX.test(t)) {
            n.nodeValue = t.replace(ORIGINAL_BRAND_REGEX, value);
            changed = true;
          }
        }
      });
      if (!changed && !el.children.length) { el.textContent = value; }
    }
    BRAND_NAME_SELECTORS.forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) { setText(el, cfg.brandName); });
    });
    FOOTER_TEXT_SELECTORS.forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) {
        el.childNodes.forEach(function (n) {
          if (n.nodeType === 3 && ORIGINAL_BRAND_REGEX.test(n.nodeValue)) {
            n.nodeValue = n.nodeValue.replace(ORIGINAL_BRAND_REGEX, cfg.brandName);
          }
        });
      });
    });
  }

  function applyBrandLinks(links) {
    var attrs = { support: "support", sales: "sales", community: "community" };
    Object.keys(attrs).forEach(function (k) {
      var target = links && links[k];
      if (!target) return;
      document.querySelectorAll('[data-ts-wa="' + k + '"]').forEach(function (el) {
        var keepText = el.getAttribute("data-ts-wa-text");
        var url = target;
        if (keepText) url += (url.indexOf("?") === -1 ? "?" : "&") + "text=" + encodeURIComponent(keepText);
        el.setAttribute("href", url);
      });
    });
  }

  function applyBrandingConfig(config) {
    config = config || {};
    var merged = {
      extensionName: config.extensionName || DEFAULTS.extensionName,
      brandName: config.brandName || DEFAULTS.brandName,
      primaryColor: isValidHexColor(config.primaryColor) ? config.primaryColor : DEFAULTS.primaryColor,
      secondaryColor: isValidHexColor(config.secondaryColor) ? config.secondaryColor : DEFAULTS.secondaryColor,
      whatsappLinks: {
        support: isValidWaUrl(config.whatsappLinks && config.whatsappLinks.support)
          ? config.whatsappLinks.support : DEFAULTS.whatsappLinks.support,
        sales: isValidWaUrl(config.whatsappLinks && config.whatsappLinks.sales)
          ? config.whatsappLinks.sales : DEFAULTS.whatsappLinks.sales,
        community: isValidWaUrl(config.whatsappLinks && config.whatsappLinks.community)
          ? config.whatsappLinks.community : DEFAULTS.whatsappLinks.community
      }
    };
    window.TS_ACTIVE_BRANDING = merged;
    try { applyBrandColor(merged.primaryColor, merged.secondaryColor); } catch (e) {}
    try { applyBrandTexts(merged); } catch (_) {}
    try { applyBrandLinks(merged.whatsappLinks); } catch (_) {}
    return merged;
  }

  function getBrandWhatsappLink(type) {
    type = type || "support";
    var b = window.TS_ACTIVE_BRANDING || DEFAULTS;
    return (b.whatsappLinks && b.whatsappLinks[type]) || DEFAULTS.whatsappLinks[type] || DEFAULTS.whatsappLinks.support;
  }

  function tsBrandName() {
    return (window.TS_ACTIVE_BRANDING && window.TS_ACTIVE_BRANDING.brandName) || DEFAULTS.brandName;
  }

  window.TS_BRANDING_DEFAULTS = DEFAULTS;
  window.applyBrandingConfig = applyBrandingConfig;
  window.getBrandWhatsappLink = getBrandWhatsappLink;
  window.tsBrandName = tsBrandName;

  applyBrandingConfig(window.TS_BRANDING_CONFIG || {});

  try {
    var pending = false;
    var obs = new MutationObserver(function () {
      if (pending) return;
      pending = true;
      requestAnimationFrame(function () {
        pending = false;
        try {
          applyBrandTexts(window.TS_ACTIVE_BRANDING || DEFAULTS);
          applyBrandLinks((window.TS_ACTIVE_BRANDING || DEFAULTS).whatsappLinks);
        } catch (_) {}
      });
    });
    var startObserver = function () {
      if (document.body) obs.observe(document.body, { childList: true, subtree: true });
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", startObserver);
    } else {
      startObserver();
    }
  } catch (_) {}
})();
